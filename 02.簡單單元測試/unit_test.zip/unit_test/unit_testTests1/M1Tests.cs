﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using unit_test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unit_test.Tests
{
    [TestClass()]
    public class M1Tests
    {
        [TestMethod()]
        public void AddTest()
        {
            // =================== 已有方法生成單元測試 ===================
            // ====== 1.Arrange 初始化 ======
            M1 m1 = new M1();
            int firstNumber = 3;
            int secondNumber = 2;
            // ====== 2.Act 實際單元運算結果、預期值 ======
            int actual = m1.Add(firstNumber, secondNumber);
            int expected = 5;
            // ====== 3.Assert 確認 (實際結果 = 預期結果) ======
            /*
                確認相等、不相等
                    Assert.AreEqual(A, B);
                    Assert.AreNotEqual(A, B);
                確認同一物件(相同記憶體位置)
                    int[] array = new[] { 1, 2 };
                    Assert.AreSame(array, array);
                確認不同物件
                    Assert.AreNotSame(new[] { 1, 2 }, new[] { 1, 2 });
                確認運算式為真為假
                    Assert.IsTrue(true);
                    Assert.IsFalse(1 == 2);
                確認是否null
                    Assert.IsNull(null);
                    Assert.IsNotNull(1 == 1);
                確認型別
                    Assert.IsInstanceOfType(1, typeof(int));
                    Assert.IsNotInstanceOfType(1, typeof(string));
                擲回 AssertFailedException
                    try
                    {
                        Assert.Fail();
                    }
                    catch (Exception ex)
                    {
                        Assert.AreEqual(1, 1);
                    }
            */
            Assert.AreEqual(expected, actual);

            // =================== 先自訂單元測試 再生成方法 ===================
            // 寫好之後 下拉 產生方法(實際內容還是要F12移過去寫)
            int actual2 = m1.Minus(firstNumber, secondNumber);
            int expected2 = 1;
            Assert.AreEqual(expected2, actual2);
        }
    }
}