﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unit_test
{
    // ===== 注意要public類別才可建立單元測試 =====
    // 建立同方案的測試專案：右鍵(類別 or 某一方法) ＞ 建立單元測試
    public class M1
    {
        public int Add(int firstNumber, int secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public int Minus(int firstNumber, int secondNumber)
        {
            return firstNumber - secondNumber;
        }
    }
}
